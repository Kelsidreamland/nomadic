from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page()
    
    # 擷取 console logs
    page.on("console", lambda msg: print(f"Browser Console [{msg.type}]: {msg.text}"))
    page.on("pageerror", lambda err: print(f"Browser Error: {err}"))
    
    print("Navigating to http://localhost:8888...")
    try:
        page.goto('http://localhost:8888', wait_until='networkidle', timeout=10000)
        print("Page loaded. Taking screenshot...")
        page.screenshot(path='/workspace/debug_blank.png', full_page=True)
    except Exception as e:
        print(f"Error during navigation: {e}")
        
    browser.close()